class CfgPatches
{
	class Sparta_Gear
	{
		units[]=
		{
			"Sparta_helmet",
			"Sparta_mask",
			"Sparta_comtacs",
			"Sparta_lights",
			"Sparta_crest"
		};
		weapons[]={};
		requiredVersion=0.1;
		requiredAddons[]=
		{
			"DZ_Characters",
			"DZ_Characters_Pants",
			"DZ_Characters_Tops",
			"DZ_Characters_Headgear",
			"DZ_Data"
		};
	};
	
};
class CfgMods
{
	class Sparta_Base
	{
		dir="Sparta_Gear";
		picture="";
		action="";
		hideName=1;
		hidePicture=1;
		name="Sparta_Gear";
		credits="Whisperr";
		author="Whisperr";
		authorID="0";
		version="1";
		extra=0;
		type="mod";
		dependencies[]=
		{
			"World"
		};
		class defs
		{
			class worldScriptModule
			{
				value="";
				files[]=
				{
					"Sparta/Scripts/4_world"
				};
			};
		};
	};
};
class CfgVehicles
{
	class Clothing_Base;
	class Clothing: Clothing_Base
	{
	};
	class GP5GasMask;
	class PlateCarrierVest;
	class BalaclavaMask_ColorBase;
	class Mich2001Helmet;
   	class Spartan_helmet_base: Mich2001Helmet
	{	
		scope=0;
		displayName="Spartan Helmet";
		descriptionShort="A modular heavily armored helmet";
		model="\Sparta\Models\helmet_g.p3d";
		repairableWithKits[]={5,8};
		repairCosts[]={30,25};
		rotationFlags=16;
		inventorySlot="Headgear";
		simulation="clothing";
		vehicleClass="Clothing";
		itemInfo[]=
		{
			"Clothing",
			"Headgear"
		};
		attachments[]=
		{
			"NVG",            
            "Spartan_Crest",
            "Spartan_Mask",
            "Spartan_Comtacs",
            "Spartan_Lights",
            "helmetFlashlight"
		};
		weight=1000;
		itemSize[]={4,3};
		absorbency=0;
		heatIsolation=0.80;
		noMask=0;
		headSelectionsToHide[]=
		{
			"Clipping_Gasmask",
			"Clipping_BandanaFace",
			"Clipping_Mich2001"
		};
		hiddenSelections[]=
		{
			"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
			"\Sparta\Data\helmet_co.paa"
		};
		class DamageSystem
        {
            class GlobalHealth
            {
                class Health
                {
                    hitpoints = 100;
                    healthLevels[] = 
                    {
                        {1.0,{"Sparta\Data\data\Helmet.rvmat", "Sparta\Data\data\Helmet.rvmat"}},
                        {0.7,{"Sparta\Data\data\Helmet.rvmat", "Sparta\Data\data\Helmet.rvmat"}},
                        {0.5,{"Sparta\Data\data\Helmet_damage.rvmat", "Sparta\Data\data\Helmet_damage.rvmat"}},
                        {0.3,{"Sparta\Data\data\Helmet_damage.rvmat", "Sparta\Data\data\Helmet_damage.rvmat"}},
                        {0.0,{"Sparta\Data\data\Helmet_destruct.rvmat", "Sparta\Data\data\Helmet_destruct.rvmat"}}};
                };
            };

			class GlobalArmor
			{
				class Projectile
				{
					class Health
					{
						damage=0.5;
					};
					class Blood
					{
						damage=0;
					};
					class Shock
					{
						damage=0.25999999;
					};
				};
				class Melee
				{
					class Health
					{
						damage=0.25;
					};
					class Blood
					{
						damage=0;
					};
					class Shock
					{
						damage=0.25;
					};
				};
				class Infected
				{
					class Health
					{
						damage=0.25;
					};
					class Blood
					{
						damage=0;
					};
					class Shock
					{
						damage=0.25;
					};
				};
				class FragGrenade
				{
					class Health
					{
						damage=0.5;
					};
					class Blood
					{
						damage=0;
					};
					class Shock
					{
						damage=0.25999999;
					};
				};
			};
		};
		class ClothingTypes
		{
			male="\Sparta\Models\helmet_m.p3d";
			female="\Sparta\Models\helmet_f.p3d";
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class pickUpItem
				{
					soundSet="pickUpPot_SoundSet";
					id=797;
				};
				class drop
				{
					soundset="BallisticHelmet_drop_SoundSet";
					id=898;
				};
			};
		};
	};
	class Spartan_Helmet_Grey: Spartan_helmet_base
	{
		scope=2;
		displayName="Spartan Helmet - Grey";
		hiddenSelectionsTextures[]=
		{
			"Sparta\Data\T_Grey_Helmet_BaseColor.paa",
			"Sparta\Data\T_Grey_Helmet_BaseColor.paa",
			"Sparta\Data\T_Grey_Helmet_BaseColor.paa"
		};
	};
	class Spartan_Helmet_Blue: Spartan_helmet_base
	{
		scope=2;
		displayName="Spartan Helmet - Blue";
		hiddenSelectionsTextures[]=
		{
			"Sparta\Data\T_Blue_Helmet_BaseColor.paa",
			"Sparta\Data\T_Blue_Helmet_BaseColor.paa",
			"Sparta\Data\T_Blue_Helmet_BaseColor.paa"
		};
	};
	class Spartan_Helmet_Yellow: Spartan_helmet_base
	{
		scope=2;
		displayName="Spartan Helmet - Yellow";
		hiddenSelectionsTextures[]=
		{
			"Sparta\Data\T_Yellow_Helmet_BaseColor.paa",
			"Sparta\Data\T_Yellow_Helmet_BaseColor.paa",
			"Sparta\Data\T_Yellow_Helmet_BaseColor.paa"
		};
	};
	class Spartan_Mask: Clothing
	{
		scope=0;
		displayName="Spartan Mask";
		descriptionShort="Attaches to the Spartan Helmet";
		weight=110;
		absorbency=0.80000001;
		heatIsolation=0.25;
		repairableWithKits[]={5,2};
		repairCosts[]={30,25};
		model="Sparta\Models\SpartaMask.p3d";
		inventorySlot[]=
		{
			"Spartan_Mask"
		};
		itemSize[]={2,2};
		rotationFlags=0;
		attachments[]={};
		simpleHiddenSelections[]=
		{
			"hide"
		};
		hiddenSelections[]=
		{
			"camoGround",
			"camoMale",
			"camoFemale",
			"zbytek"
		};
		hiddenSelectionsTextures[]=
		{
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa"
		};
		class DamageSystem
		{
			class GlobalHealth
			{
				class Health
				{
					hitpoints=100;
					healthLevels[]=
					{
						
						{
							1,
							
							{
								"DZ\characters\headgear\data\BaseballCapII.rvmat"
							}
						},
						
						{
							0.69999999,
							
							{
								"DZ\characters\headgear\data\BaseballCapII.rvmat"
							}
						},
						
						{
							0.5,
							
							{
								"DZ\characters\headgear\data\BaseballCapII_damage.rvmat"
							}
						},
						
						{
							0.30000001,
							
							{
								"DZ\characters\headgear\data\BaseballCapII_damage.rvmat"
							}
						},
						
						{
							0,
							
							{
								"DZ\characters\headgear\data\BaseballCapII_destruct.rvmat"
							}
						}
					};
				};
			};
		};
		class AnimEvents
		{
			class SoundWeapon
			{
				class pickUpItem
				{
					soundSet="Shirt_pickup_SoundSet";
					id=797;
				};
				class drop
				{
					soundset="Shirt_drop_SoundSet";
					id=898;
				};
			};
		};
	};
	class Spartan_Mask_Blue: Spartan_Mask
	{
		scope=2;
		displayName="Spartan Mask - Blue";
		color="OD";
		hiddenSelectionsTextures[]=
		{
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Blue_Equipment_BaseColor.paa"
		};
	};
	class Spartan_Mask_Grey: Spartan_Mask
	{
		scope=2;
		displayName="Spartan Mask - Grey";
		color="Tan";
		hiddenSelectionsTextures[]=
		{
			"\Sparta\Data\T_Grey_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Grey_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Grey_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Grey_Equipment_BaseColor.paa"
		};
	};
	class Spartan_Mask_Yellow: Spartan_Mask
	{
		scope=2;
		displayName="Spartan Mask - Yellow";
		color="Black";
		hiddenSelectionsTextures[]=
		{
			"\Sparta\Data\T_Yellow_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Yellow_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Yellow_Equipment_BaseColor.paa",
			"\Sparta\Data\T_Yellow_Equipment_BaseColor.paa"
		};
	};
class CfgSlots
{
    class Slot_Spartan_Mask
    {
        name = "Spartan_Mask";
        displayName = "Spartan_Mask";
        ghostIcon = "Mask";
    };
    class Slot_Spartan_Comtacs
    {
        name = "Spartan_Comtacs";
        displayName = "Spartan_Comtacs";
        ghostIcon = "walkietalkie";
    };
	 class Slot_Spartan_Lights
    {
        name = "Spartan_Lights";
        displayName = "Spartan_Lights";
        ghostIcon = "helmetFlashlight";
    };
	 class Slot_Spartan_Crest
    {
        name = "Spartan_Crest";
        displayName = "Spartan_Crest";
        ghostIcon = "armband";
    };
};
class CfgNonAIVehicles
{
	class ProxyAttachment;
	class Proxyhelmet_flashlight: ProxyAttachment
	{
		scope=2;
		inventorySlot[]=
		{
			"helmetFlashlight"
		};
		model="\DZ\weapons\attachments\weaponlight_universal.p3d";
	};
	class ProxySpartaMask: ProxyAttachment
	{
		scope=2;
		inventorySlot[]=
		{
			"Slot_Spartan_Mask"
		};
		model="\Sparta\Proxies\SpartaMask.p3d";
	};
	class ProxySpartacomtacs: ProxyAttachment
	{
		scope=2;
		inventorySlot[]=
		{
			"Slot_Spartan_Comtacs"
		};
		model="\Sparta\Proxies\Spartacomtacs.p3d";
	};
	class ProxySpartaLights: ProxyAttachment
	{
		scope=2;
		inventorySlot[]=
		{
			"Slot_Spartan_Lights"
		};
		model="\Sparta\Proxies\SpartaLights.p3d";
	};
	class ProxySpartaCrest: ProxyAttachment
	{
		scope=2;
		inventorySlot[]=
		{
			"Slot_Spartan_Crest"
		};
		model="\Sparta\Proxies\SpartaCrest.p3d";
		};
	};
};